#ifndef _TIMER_H
#define _TIMER_H
#include "sys.h"

void TIM4_Ctrl_Init(u32 arr,u32 psc);
void TIM4_IRQHandler(void);
void TIM3_IRQHandler(void);
void TIM3_Int_Init(u16 arr,u16 psc);
void TIM14_PWM_Init(u32 arr,u32 psc);
void TIM5_CH1_Cap_Init(u32 arr,u16 psc);
void TIM5_IRQHandler(void);





#endif


