#include "sys.h"
#include "delay.h"  
#include "usart.h"  
//#include "led.h"
#include "lcd.h"
#include "ov7670.h"
//#include "ov7670cfg.h"
#include "timer.h"	  		 
#include "sccb.h"	
#include "exti.h"
#include "stm32f4xx.h"
//#include "fdc2214.h"
#include "key.h"
#include "math.h"
#include "image2lcd.h"
#define KEYN 34
#define THRESHOLD 23   //�궨����ֵ

//#define CHOOSE
//#ifdef CHOOSE

//ALIENTEK ̽����STM32F407������ ʵ��13
//TFTLCD��ʾʵ��  
//����֧�֣�www.openedv.com
//�������������ӿƼ����޹�˾
extern u8 ov_sta;	//��exit.c���涨��
extern u8 ov_frame;	//��timer.c���涨��	
u16 color,color1,color_min=1000;
u16 aa,bb,AA,BB;
u16 at,bt,aat,bbt;
u16 P[2][KEYN];
u16 hchar=0,lchar=0;
u8 fflag=0;
u8 ffflag=0;
char data[32];
int data_index0,data_index;

void KeyBoard_Measure()//�����������
{
	u32 c,d;
	u32 dian=0;
	if(ov_sta==2) 
	{
		LCD_Scan_Dir(U2D_L2R);		//���ϵ���,������ 
		LCD_Set_Window((lcddev.width-320)/2,(lcddev.height-240)/2,320,240);
		LCD_WriteRAM_Prepare();     //��ʼд��GRAM	
		
		OV7670_RRST=0;				//��ʼ��λ��ָ�� 
		OV7670_RCK=0;
		OV7670_RCK=1;
		OV7670_RCK=0;
		OV7670_RRST=1;				//��λ��ָ����� 
		OV7670_RCK=1; 
		
		for (aa=0;aa<240;aa++)
		{
			for(bb=0;bb<320;bb++)
			{
				OV7670_RCK=0;
				AA=GPIOF->IDR;						
				OV7670_RCK=1;  
				OV7670_RCK=0;
				BB=GPIOF->IDR&0x001f;	//��ȡBlue��ɫ							
				OV7670_RCK=1;  
				color=(AA<<8)|BB;
				
				if(BB>=THRESHOLD)//��ֵ�ж�
				{
					dian++;//�õ���������������ˢΪ�ڣ�����ֻȡ��һ��
					LCD->LCD_RAM=0xffff; 
					if(dian>=15){
						ffflag=1;
						dian=0;
					for(c=0;c<(76800-aa*320-bb-1);c++)//ˢ��ʣ�������
					{
						LCD->LCD_RAM=0x0101;
					}
				//��¼����
					at=aa;
					bt=bb;
					//��ʾ����
					LCD_Scan_Dir(L2R_U2D);
					LCD_ShowChar(10,250,'x',24,0);//X���꣬Y���꣬�ַ������ģʽ
					LCD_ShowNum(30,250,aa,3,24);//X���꣬Y���꣬���֣���λ��
					LCD_ShowChar(10,280,'y',24,0);//X���꣬Y���꣬�ַ������ģʽ
					LCD_ShowNum(30,280,bb,3,24);//X���꣬Y���꣬���֣���λ��
// 					delayms(1000);
					LCD_Scan_Dir(U2D_L2R);		//���ϵ���,������ 
					aa=240;bb=320;//����a,b-forѭ��
				}
					else ffflag=0;
			}
				else
				{
					ffflag=0;
					LCD->LCD_RAM=0x0001;//ȫ0�Ứ��
				}
			}							
		}	 
		EXTI->PR=1<<9;     			//���LINE9�ϵ��жϱ�־λ
		ov_sta=0;					//��ʼ��һ�βɼ�
 	//	ov_frame++; 
		LCD_Scan_Dir(DFT_SCAN_DIR);	//�ָ�Ĭ��ɨ�跽�� 	
	}
}

//**********************************************************
void KeyBoard_SendData(u16 x_0,u16 y_0,u16 x_1,u16 y_1,u8 detia_x,u8 detia_y,unsigned char Data,u16 index)
{
	if(x_1<(x_0+detia_x)&&x_1>(x_0-detia_x)&&y_1<(y_0+detia_y)&&y_1>(y_0-detia_y))
	{		
		data_index=index-1;
		//LCD_ShowChar(100+16*nchar,100,Data,24,0);
		//nchar++;
	}
}
void KeyBoard_Switch(u16 x,u16 y)
{	
	u8 detia_x=8,detia_y=10;//�����ȵ���
	u8 ii;
	data_index=-2;
	
	for(ii=0;ii<KEYN;ii++){
	KeyBoard_SendData(P[0][ii],P[1][ii],x,y,detia_x,detia_y,data[ii],ii);//3
	}
	
}
//********************************************************

 void camera_refresh(void)	//����test��������ʾ
{
	u32 j; 
	if(ov_sta==2)
	{
		// LCD_Set_Window(80,100,240,320);                //???????   
		LCD_Scan_Dir(U2D_L2R);		//���ϵ���,������ 
		//if(lcddev.id==0X1963)
		//	LCD_Set_Window((lcddev.width-240)/2,(lcddev.height-320)/2,240,320);
	//	else if(lcddev.id==0X5510||lcddev.id==0X5310)
	LCD_Set_Window((lcddev.width-320)/2,(lcddev.height-240)/2,320,240);
	//	LCD_SetCursor(0x00,0x0000);	//���ù��λ�� 
		LCD_WriteRAM_Prepare();     //��ʼд��GRAM	
		OV7670_RRST=0;				//��ʼ��λ��ָ�� 
		OV7670_RCK=0;
		OV7670_RCK=1;
		OV7670_RCK=0;
		OV7670_RRST=1;				//��λ��ָ����� 
		OV7670_RCK=1;  
		for(j=0;j<76800;j++)	//�ֱ���240*320=76800
		{
			OV7670_RCK=0;
			color=GPIOF->IDR&0XFF;	//������
			OV7670_RCK=1; 
			color<<=8;  
			OV7670_RCK=0;
			color|=GPIOF->IDR&0XFF;	//������
			OV7670_RCK=1; 
			LCD->LCD_RAM=color;  
		}   							 
		EXTI->PR=1<<9;     			//���LINE9�ϵ��жϱ�־λ
		ov_sta=0;					//��ʼ��һ�βɼ�
 	//	ov_frame++; 
		LCD_Scan_Dir(DFT_SCAN_DIR);	//�ָ�Ĭ��ɨ�跽�� 
	} 
}	

//#else


extern float res0,res1,res2,res3,res4,res5,res6,res7;
void mode1();
void mode2();
void mode3();
void mode4();
void mode5();
void mode6();
void mode7();
int laby[10][10]={
		{1,1,1,1,1,1,1,1,1,1},
		{0,0,1,0,0,0,0,0,0,1},
		{1,0,1,1,1,1,1,1,0,1},
		{1,0,0,0,1,0,0,1,0,1},
		{1,0,0,0,1,0,0,1,0,1},
		{1,0,1,0,1,0,1,1,0,1},
		{1,0,1,0,0,0,0,0,0,1},
		{1,0,1,1,1,1,1,1,0,1},
		{1,0,0,0,0,1,0,0,0,1},
		{1,1,1,1,1,1,1,1,0,1}
 };
double ca,h;
static u8 FLAG_MENU=0;
static u8 FLAG_MODE=1;
//float temp0,temp1,temp2,temp3;
u32 fr0,fr1,fr2,fr3,fr4,fr5,fr6,fr7;
u32 fr0_total,fr1_total,fr2_total,fr3_total,fr4_total,fr5_total,fr6_total,fr7_total;
static u32 yz0,yz1=740,yz2=1320,yz3=1740,yz4=2000,yz5,yz6;		//ѧϰ����ֵ
static u32 yzz0,yzz1=1054,yzz2=1820,yzz3=2277,yzz4=2842,yzz5,yzz6;		//ѧϰ����ֵ
extern const unsigned char fist[2926] ;
extern const unsigned char scissors[9768];
extern const unsigned char paper[12008];
extern const unsigned char blank[10728] ;
u32 x,y;
u32 x0,y0;
u32 height=0,c=0;
u8 flag=0;
u32 b;
u32 d=0;
u32 sample=40;
u8 num,num2;
extern float res0_inia,res1_inia,res2_inia,res3_inia,res4_inia,res5_inia,res6_inia,res7_inia;
int main(void)
{
	
	
	u8 key;           //�����ֵ
	u8 key2;
	KEY_Init();       //��ʼ���밴�����ӵ�Ӳ���ӿ�
	uart_init(115200);
	delay_init(84);
	LCD_Init();
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//����ϵͳ�ж����ȼ�����2
	LCD_Set_Window(0,0,1000,1000);
	delay_ms(100);
	TIM4_Ctrl_Init(20000-1,84-1);  //20ms

	Stm32_Clock_Init(336,8,2,7);//����ʱ��,168Mhz 
	delay_init(168);			//��ʱ��ʼ��  
	uart_init(115200);		//��ʼ�����ڲ�����Ϊ115200 
 	LCD_Init();
  OV7670_Init();
	POINT_COLOR=RED;//��������Ϊ��ɫ 
	LCD_ShowString(60,50,200,16,16,"WarShip STM32");	
	LCD_ShowString(60,70,200,16,16,"OV7670 TEST");	
	LCD_ShowString(60,90,200,16,16,"ATOM@ALIENTEK");
	LCD_ShowString(60,110,200,16,16,"2012/9/14");  
	LCD_ShowString(60,130,200,16,16,"KEY0:Light Mode");
	LCD_ShowString(60,150,200,16,16,"KEY1:Saturation");
	LCD_ShowString(60,170,200,16,16,"KEY2:Brightness");
	LCD_ShowString(60,190,200,16,16,"KEY_UP:Contrast");
	LCD_ShowString(60,210,200,16,16,"TPAD:Effects");	 
  	LCD_ShowString(60,230,200,16,16,"OV7670 Init...");	  
	while(OV7670_Init())//��ʼ��OV7670
	{
		LCD_ShowString(60,230,200,16,16,"OV7670 Error!!");
		delay_ms(200);
	    LCD_Fill(60,230,239,246,WHITE);
		delay_ms(200);
	}
 	LCD_ShowString(60,230,200,16,16,"OV7670 Init OK");
	delay_ms(1500);	 
	OV7670_Light_Mode(2);
	OV7670_Color_Saturation(2);
	OV7670_Brightness(4);
	OV7670_Contrast(2);
//	TIM3_Int_Init(10000-1,8399);			//10Khz����Ƶ��,1�����ж�		
	EXTI9_Init();						//ʹ�ܶ�ʱ������ 
OV7670_Window_Set(10,174,240,320);	//���ô���	

  	OV7670_CS=0;	
//���ڷ�ѧϰ���ĸ�������x y����ֵ
P[0][0]=80;P[1][0]=282;
P[0][1]=80;P[1][1]=282;
P[0][2]=25;P[1][2]=274;
P[0][3]=25;P[1][3]=235;
P[0][4]=24;P[1][4]=176;
P[0][5]=23;P[1][5]=132;
P[0][6]=27;P[1][6]=58;
P[0][7]=31;P[1][7]=7;
P[0][8]=31;P[1][8]=7;
P[0][9]=60;P[1][9]=286;
P[0][10]=57;P[1][10]=256;
P[0][11]=56;P[1][11]=190;
P[0][12]=55;P[1][12]=139;
P[0][13]=57;P[1][13]=107;
P[0][14]=62;P[1][14]=53;
P[0][15]=62;P[1][15]=5;
P[0][16]=62;P[1][16]=5;
P[0][17]=62;P[1][17]=5;
P[0][18]=87;P[1][18]=313;
P[0][19]=80;P[1][19]=283;
P[0][20]=81;P[1][20]=231;
P[0][21]=79;P[1][21]=192;
P[0][22]=79;P[1][22]=149;
P[0][23]=82;P[1][23]=83;
P[0][24]=84;P[1][24]=33;
P[0][25]=97;P[1][25]=4;
P[0][26]=97;P[1][26]=4;
P[0][27]=111;P[1][27]=288;
P[0][28]=109;P[1][28]=240;
P[0][29]=107;P[1][29]=194;
P[0][30]=111;P[1][30]=146;
P[0][31]=109;P[1][31]=113;


data[0]='2';
data[1]='3';
data[2]='4';
data[3]='5';
data[4]='6';
data[5]='7';
data[6]='8';
data[7]='9';
data[8]='0';
data[9]='Q';
data[10]='W';
data[11]='E';
data[12]='R';
data[13]='T';
data[14]='Y';
data[15]='U';
data[16]='I';
data[17]='O';
data[18]='P';
data[19]='A';
data[20]='S';
data[21]='D';
data[22]='F';
data[23]='G';
data[24]='H';
data[25]='J';
data[26]='K';
data[27]='L';
data[28]='Z';
data[29]='X';
data[30]='C';
data[31]='V';
data[32]='B';
data[33]='N';
data[34]='M';


	POINT_COLOR=BLACK;
	LCD_ShowString(5,120,60,60,16,"mouse");		//ģʽ1
	LCD_ShowString(5,150,60,60,16,"keyboard");		//ģʽ2��������
	LCD_ShowString(5,180,60,60,16,"training");	//ģʽ3��ѵ��ģʽ
	LCD_ShowString(5,210,60,60,16,"   ");	//ģʽ4 �
	LCD_ShowString(5,240,60,60,16,"maze");	//ģʽ5
	LCD_ShowString(5,270,60,60,16,"   ");	//ģʽ6
	LCD_ShowString(5,300,60,60,16,"test");	//ģʽ7 �۲�����ͷͼ��
	LCD_ShowString(80,120,60,60,16,"<--");
	
	while(1){
		key=KEY_Scan(0);		//�õ���ֵ
	  if(FLAG_MENU==0)//�ڲ˵�������
		{	
		if(key)
		{				   
			switch(key)
			{				 
				case KEYUP_PRES:	//����
				{
					if(FLAG_MODE==7)
					{
					LCD_Clear(WHITE);
					POINT_COLOR=BLACK;
					LCD_ShowString(5,120,60,60,16,"mouse");		//ģʽ1
					LCD_ShowString(5,150,60,60,16,"keyboard");		//ģʽ2��������
					LCD_ShowString(5,180,60,60,16,"training");	//ģʽ3��ѵ��ģʽ
					LCD_ShowString(5,210,60,60,16,"   ");	//ģʽ4 
					LCD_ShowString(5,240,60,60,16,"maze");	//ģʽ5
					LCD_ShowString(5,270,60,60,16,"   ");	//ģʽ6
					LCD_ShowString(5,300,60,60,16,"test");	//ģʽ7 �۲�����ͷͼ��
					LCD_ShowString(80,270,60,60,16,"<--");
					FLAG_MODE=6;
					}
					else if(FLAG_MODE==6)
					{
					LCD_Clear(WHITE);
					POINT_COLOR=BLACK;
					LCD_ShowString(5,120,60,60,16,"mouse");		//ģʽ1
					LCD_ShowString(5,150,60,60,16,"keyboard");		//ģʽ2��������
					LCD_ShowString(5,180,60,60,16,"training");	//ģʽ3��ѵ��ģʽ
					LCD_ShowString(5,210,60,60,16,"   ");	//ģʽ4 
					LCD_ShowString(5,240,60,60,16,"maze");	//ģʽ5
					LCD_ShowString(5,270,60,60,16,"   ");	//ģʽ6�
					LCD_ShowString(5,300,60,60,16,"test");	//ģʽ7 �۲�����ͷͼ��
					LCD_ShowString(80,240,60,60,16,"<--");
					FLAG_MODE=5;
					}
					else if(FLAG_MODE==5)
					{
					LCD_Clear(WHITE);
					POINT_COLOR=BLACK;
					LCD_ShowString(5,120,60,60,16,"mouse");		//ģʽ1
					LCD_ShowString(5,150,60,60,16,"keyboard");		//ģʽ2��������
					LCD_ShowString(5,180,60,60,16,"training");	//ģʽ3��ѵ��ģʽ
					LCD_ShowString(5,210,60,60,16,"   ");	//ģʽ4 �
					LCD_ShowString(5,240,60,60,16,"maze");	//ģʽ5
					LCD_ShowString(5,270,60,60,16,"   ");	//ģʽ6�
					LCD_ShowString(5,300,60,60,16,"test");	//ģʽ7 �۲�����ͷͼ��
					LCD_ShowString(80,210,60,60,16,"<--");
					FLAG_MODE=4;
					}
					else if(FLAG_MODE==4)
					{
					LCD_Clear(WHITE);
					POINT_COLOR=BLACK;
					LCD_ShowString(5,120,60,60,16,"mouse");		//ģʽ1
					LCD_ShowString(5,150,60,60,16,"keyboard");		//ģʽ2��������
					LCD_ShowString(5,180,60,60,16,"training");	//ģʽ3��ѵ��ģʽ
					LCD_ShowString(5,210,60,60,16,"   ");	//ģʽ4 
					LCD_ShowString(5,240,60,60,16,"maze");	//ģʽ5
					LCD_ShowString(5,270,60,60,16," ");	//ģʽ6
					LCD_ShowString(5,300,60,60,16,"test");	//ģʽ7 �۲�����ͷͼ��
					LCD_ShowString(80,180,60,60,16,"<--");
					FLAG_MODE=3;
					}
					else if(FLAG_MODE==3)
					{
					LCD_Clear(WHITE);
					POINT_COLOR=BLACK;
					LCD_ShowString(5,120,60,60,16,"mouse");		//ģʽ1
					LCD_ShowString(5,150,60,60,16,"keyboard");		//ģʽ2��������
					LCD_ShowString(5,180,60,60,16,"training");	//ģʽ3��ѵ��ģʽ
					LCD_ShowString(5,210,60,60,16," ");	//ģʽ4 
					LCD_ShowString(5,240,60,60,16,"maze");	//ģʽ5
					LCD_ShowString(5,270,60,60,16,"   ");	//ģʽ6
					LCD_ShowString(5,300,60,60,16,"test");	//ģʽ7 �۲�����ͷͼ��
					LCD_ShowString(80,150,60,60,16,"<--");
					FLAG_MODE=2;
					}
					else if(FLAG_MODE==2)
					{
					LCD_Clear(WHITE);
					POINT_COLOR=BLACK;
					LCD_ShowString(5,120,60,60,16,"mouse");		//ģʽ1
					LCD_ShowString(5,150,60,60,16,"keyboard");		//ģʽ2��������
					LCD_ShowString(5,180,60,60,16,"training");	//ģʽ3��ѵ��ģʽ
					LCD_ShowString(5,210,60,60,16,"  ");	//ģʽ4 
					LCD_ShowString(5,240,60,60,16,"maze");	//ģʽ5
					LCD_ShowString(5,270,60,60,16,"  ");	//ģʽ6
					LCD_ShowString(5,300,60,60,16,"test");	//ģʽ7 �۲�����ͷͼ��
					LCD_ShowString(80,120,60,60,16,"<--");
					FLAG_MODE=1;
					}
					break;
				}
				case KEYRIGHT_PRES:	//����
					break;
				case KEYDOWN_PRES:	//����
				{
					if(FLAG_MODE==1)
					{
					POINT_COLOR=BLACK;
					LCD_Clear(WHITE);
					POINT_COLOR=BLACK;
					LCD_ShowString(5,120,60,60,16,"mouse");		//ģʽ1
					LCD_ShowString(5,150,60,60,16,"keyboard");		//ģʽ2��������
					LCD_ShowString(5,180,60,60,16,"training");	//ģʽ3��ѵ��ģʽ
					LCD_ShowString(5,210,60,60,16,"  ");	//ģʽ4 fdc�ĸ�ͨ������
					LCD_ShowString(5,240,60,60,16,"maze");	//ģʽ5
					LCD_ShowString(5,270,60,60,16,"  ");	//ģʽ6�
					LCD_ShowString(5,300,60,60,16,"test");	//ģʽ7 �۲�����ͷͼ��
					LCD_ShowString(80,150,60,60,16,"<--");
					FLAG_MODE=2;
					}
					else if(FLAG_MODE==2)
					{
					POINT_COLOR=BLACK;
					LCD_Clear(WHITE);
					POINT_COLOR=BLACK;
					LCD_ShowString(5,120,60,60,16,"mouse");		//ģʽ1
					LCD_ShowString(5,150,60,60,16,"keyboard");		//ģʽ2��������
					LCD_ShowString(5,180,60,60,16,"training");	//ģʽ3��ѵ��ģʽ
					LCD_ShowString(5,210,60,60,16,"  ");	//ģʽ4 �
					LCD_ShowString(5,240,60,60,16,"maze");	//ģʽ5
					LCD_ShowString(5,270,60,60,16,"  ");	//ģʽ6
					LCD_ShowString(5,300,60,60,16,"test");	//ģʽ7 �۲�����ͷͼ��
					LCD_ShowString(80,180,60,60,16,"<--");
						FLAG_MODE=3;
					}
					else if(FLAG_MODE==3)
					{
					POINT_COLOR=BLACK;
					LCD_Clear(WHITE);
					POINT_COLOR=BLACK;
					LCD_ShowString(5,120,60,60,16,"mouse");		//ģʽ1
					LCD_ShowString(5,150,60,60,16,"keyboard");		//ģʽ2��������
					LCD_ShowString(5,180,60,60,16,"training");	//ģʽ3��ѵ��ģʽ
					LCD_ShowString(5,210,60,60,16," ");	//ģʽ4 
					LCD_ShowString(5,240,60,60,16,"maze");	//ģʽ5
					LCD_ShowString(5,270,60,60,16,"  ");	//ģʽ6��
					LCD_ShowString(5,300,60,60,16,"test");	//ģʽ7 �۲�����ͷͼ��
					LCD_ShowString(80,210,60,60,16,"<--");
						FLAG_MODE=4;						
					}
					else if(FLAG_MODE==4)
					{
					POINT_COLOR=BLACK;
					LCD_Clear(WHITE);
					POINT_COLOR=BLACK;
					LCD_ShowString(5,120,60,60,16,"mouse");		//ģʽ1
					LCD_ShowString(5,150,60,60,16,"keyboard");		//ģʽ2��������
					LCD_ShowString(5,180,60,60,16,"training");	//ģʽ3��ѵ��ģʽ
					LCD_ShowString(5,210,60,60,16,"  ");	//ģʽ4 
					LCD_ShowString(5,240,60,60,16,"maze");	//ģʽ5
					LCD_ShowString(5,270,60,60,16,"  ");	//ģʽ6��
					LCD_ShowString(5,300,60,60,16,"test");	//ģʽ7 �۲�����ͷͼ��
					LCD_ShowString(80,240,60,60,16,"<--");
						FLAG_MODE=5;						
					}
					else if(FLAG_MODE==5)
					{
					POINT_COLOR=BLACK;
					LCD_Clear(WHITE);
					POINT_COLOR=BLACK;
					LCD_ShowString(5,120,60,60,16,"mouse");		//ģʽ1
					LCD_ShowString(5,150,60,60,16,"keyboard");		//ģʽ2��������
					LCD_ShowString(5,180,60,60,16,"training");	//ģʽ3��ѵ��ģʽ
					LCD_ShowString(5,210,60,60,16,"  ");	//ģʽ4 
					LCD_ShowString(5,240,60,60,16,"maze");	//ģʽ5
					LCD_ShowString(5,270,60,60,16,"  ");	//ģʽ6
					LCD_ShowString(5,300,60,60,16,"test");	//ģʽ7 �۲�����ͷͼ��
					LCD_ShowString(80,270,60,60,16,"<--");
						FLAG_MODE=6;						
					}
					else if(FLAG_MODE==6)
					{
					POINT_COLOR=BLACK;
					LCD_Clear(WHITE);
					POINT_COLOR=BLACK;
					LCD_ShowString(5,120,60,60,16,"mouse");		//ģʽ1
					LCD_ShowString(5,150,60,60,16,"keyboard");		//ģʽ2��������
					LCD_ShowString(5,180,60,60,16,"training");	//ģʽ3��ѵ��ģʽ
					LCD_ShowString(5,210,60,60,16,"  ");	//ģʽ4 
					LCD_ShowString(5,240,60,60,16,"maze");	//ģʽ5
					LCD_ShowString(5,270,60,60,16,"  ");	//ģʽ6
					LCD_ShowString(5,300,60,60,16,"test");	//ģʽ7 �۲�����ͷͼ��
					LCD_ShowString(80,300,60,60,16,"<--");
						FLAG_MODE=7;						
					}
					break;
				}
				case KEYLEFT_PRES:	//ȷ�� 
				{
					if(FLAG_MODE==1)
					{
						FLAG_MENU=MODE_1;
						LCD_Clear(WHITE);
					}
					if(FLAG_MODE==2)
					{
						FLAG_MENU=MODE_2;
						LCD_Clear(WHITE);
					}
					if(FLAG_MODE==3)
					{
						FLAG_MENU=MODE_3;
						LCD_Clear(WHITE);
					}
					if(FLAG_MODE==4)
					{
						FLAG_MENU=MODE_4;
						LCD_Clear(WHITE);
					}
					if(FLAG_MODE==5)
					{
						FLAG_MENU=MODE_5;
						LCD_Clear(WHITE);
					}
					if(FLAG_MODE==6)
					{
						FLAG_MENU=MODE_6;
						LCD_Clear(WHITE);
					}
					if(FLAG_MODE==7)
					{
						FLAG_MENU=MODE_7;
						LCD_Clear(WHITE);
					}
					break;
					}
			}
		}	
	}
			if(FLAG_MENU==MODE_1)//ģʽ1
			{
					LCD_ShowString(5,100,60,60,16,"mouse");
					while(KEY_Scan(0)!=1){mode1();}//�����˳���ʼ����mode1�����		
				FLAG_MENU=0;
				FLAG_MODE=1;
					LCD_Clear(WHITE);
						POINT_COLOR=BLACK;
					LCD_ShowString(5,120,60,60,16,"mouse");		//ģʽ1
					LCD_ShowString(5,150,60,60,16,"keyboard");		//ģʽ2��������
					LCD_ShowString(5,180,60,60,16,"training");	//ģʽ3��ѵ��ģʽ
					LCD_ShowString(5,210,60,60,16," ");	//ģʽ4 
					LCD_ShowString(5,240,60,60,16,"maze");	//ģʽ5
					LCD_ShowString(5,270,60,60,16," ");	//ģʽ6��
					LCD_ShowString(5,300,60,60,16,"test");	//ģʽ7 �۲�����ͷͼ��
					LCD_ShowString(80,120,60,60,16,"<--");
			}	
			
			if(FLAG_MENU==MODE_2)//ģʽ2��������
		{
			TIM_Cmd(TIM4, DISABLE);  //ʹ��TIM4	
			hchar=0;
			lchar=0;
					LCD_ShowString(5,100,60,60,16,"keyboard");
					while(KEY_Scan(0)!=1){mode2();}
				FLAG_MENU=0;
				FLAG_MODE=2;
					LCD_Clear(WHITE);
						POINT_COLOR=BLACK;
						LCD_ShowString(5,120,60,60,16,"mouse");		//ģʽ1
					LCD_ShowString(5,150,60,60,16,"keyboard");		//ģʽ2��������
					LCD_ShowString(5,180,60,60,16,"training");	//ģʽ3��ѵ��ģʽ
					LCD_ShowString(5,210,60,60,16," ");	//ģʽ4 
					LCD_ShowString(5,240,60,60,16,"maze");	//ģʽ5
					LCD_ShowString(5,270,60,60,16,"  ");	//ģʽ6
					LCD_ShowString(5,300,60,60,16,"test");	//ģʽ7 �۲�����ͷͼ��
					LCD_ShowString(80,150,60,60,16,"<--");
		}
		
			if(FLAG_MENU==MODE_3)//ģʽ3ѵ��
		{
			TIM_Cmd(TIM4, DISABLE);  //ʹ��TIM4	
					LCD_ShowString(5,100,60,60,16,"training");
					mode3();
			}	
		

			if(FLAG_MENU==MODE_4)//ģʽ4
		{
			TIM_Cmd(TIM4, ENABLE);  //ʹ��TIM4	
					LCD_ShowString(5,100,60,60,16," ");
					while(KEY_Scan(0)!=1){mode4();}//�����˳���ʼ����mode4�����	
					FLAG_MENU=0;
					FLAG_MODE=4;
					LCD_Clear(WHITE);
						POINT_COLOR=BLACK;
						LCD_ShowString(5,120,60,60,16,"mouse");		//ģʽ1
					LCD_ShowString(5,150,60,60,16,"keyboard");		//ģʽ2��������
					LCD_ShowString(5,180,60,60,16,"training");	//ģʽ3��ѵ��ģʽ
					LCD_ShowString(5,210,60,60,16,"  ");	//ģʽ4 
					LCD_ShowString(5,240,60,60,16,"maze");	//ģʽ5
					LCD_ShowString(5,270,60,60,16,"  ");	//ģʽ6��
					LCD_ShowString(5,300,60,60,16,"test");	//ģʽ7 �۲�����ͷͼ��
					LCD_ShowString(80,210,60,60,16,"<--");
			}	
		if(FLAG_MENU==MODE_5)//ģʽ5
		{
					LCD_ShowString(5,100,60,60,16,"maze");
					mode5();
					//while(KEY_Scan(0)!=1){mode5();}//�����˳���ʼ����mode5�����	
					FLAG_MENU=0;
					FLAG_MODE=5;
					LCD_Clear(WHITE);
						POINT_COLOR=BLACK;
						LCD_ShowString(5,120,60,60,16,"mouse");		//ģʽ1
					LCD_ShowString(5,150,60,60,16,"keyboard");		//ģʽ2��������
					LCD_ShowString(5,180,60,60,16,"training");	//ģʽ3��ѵ��ģʽ
					LCD_ShowString(5,210,60,60,16,"  ");	//ģʽ4 
					LCD_ShowString(5,240,60,60,16,"maze");	//ģʽ5
					LCD_ShowString(5,270,60,60,16,"  ");	//ģʽ6��
					LCD_ShowString(5,300,60,60,16,"test");	//ģʽ7 �۲�����ͷͼ��
					LCD_ShowString(80,240,60,60,16,"<--");
			}	
		if(FLAG_MENU==MODE_6)//ģʽ6
		{
			TIM_Cmd(TIM4, ENABLE);  //ʹ��TIM4	
			key2=0;
			POINT_COLOR=RED;
					LCD_ShowString(5,100,60,60,16,"6");
		//			while(KEY_Scan(0)!=1){mode6();}//�����˳���ʼ����mode4�����	
		while(!(key2=KEY_Scan(0))){mode6();	}
		      FLAG_MENU=0;
					FLAG_MODE=6;
					LCD_Clear(WHITE);
						POINT_COLOR=BLACK;
						LCD_ShowString(5,120,60,60,16,"  ");		//ģʽ1
					LCD_ShowString(5,150,60,60,16,"keyboard");		//ģʽ2��������
					LCD_ShowString(5,180,60,60,16,"training");	//ģʽ3��ѵ��ģʽ
					LCD_ShowString(5,210,60,60,16,"fdc");	//ģʽ4 
					LCD_ShowString(5,240,60,60,16,"  ");	//ģʽ5
					LCD_ShowString(5,270,60,60,16,"mouse");	//ģʽ6
					LCD_ShowString(5,300,60,60,16,"test");	//ģʽ7 �۲�����ͷͼ��
					LCD_ShowString(80,270,60,60,16,"<--");
		}
			
		if(FLAG_MENU==MODE_7)//ģʽ7
		{
			TIM_Cmd(TIM4, DISABLE);  //ʹ��TIM4	
					LCD_ShowString(5,100,60,60,16,"test");
					while(KEY_Scan(0)!=1){mode7();}//�����˳���ʼ����mode7�����	
					FLAG_MENU=0;
					FLAG_MODE=7;
					LCD_Clear(WHITE);
						POINT_COLOR=BLACK;
						LCD_ShowString(5,120,60,60,16,"mouse");		//ģʽ1
					LCD_ShowString(5,150,60,60,16,"keyboard");		//ģʽ2��������
					LCD_ShowString(5,180,60,60,16,"training");	//ģʽ3��ѵ��ģʽ
					LCD_ShowString(5,210,60,60,16,"    ");	//ģʽ4 
					LCD_ShowString(5,240,60,60,16,"maze");	//ģʽ5
					LCD_ShowString(5,270,60,60,16," ");	//ģʽ6�
					LCD_ShowString(5,300,60,60,16,"test");	//ģʽ7 �۲�����ͷͼ��
					LCD_ShowString(80,300,60,60,16,"<--");
			}	
	}	

}	

	

void mode1()			//mouse
{
	int i=0,j=0;
	aat=at;
	bbt=bt;
	KeyBoard_Measure();
	if(!((aat==at)&&(bbt==bt)))
	{
	POINT_COLOR=BLACK;
	for (i=0;i<5;i++)
	for (j=0;j<5;j++)
	{
		if ((at+i>=lcddev.width)||(bt+j>=lcddev.height)) continue;
	  LCD_DrawPoint(at+i,bt+j);	
	}
	POINT_COLOR=WHITE;
	for (i=0;i<5;i++)
	for (j=0;j<5;j++)
	{
		if ((aat+i>=lcddev.width)||(bbt+j>=lcddev.height)) continue;
	  LCD_DrawPoint(aat+i,bbt+j);	
	}
	POINT_COLOR=BLACK;
  }
		}

void mode2()			//��������ģʽ��֧��������
{
		KeyBoard_Measure();
		//camera_refresh();//������ʾ
	 KeyBoard_Switch(at,bt);
	if((data_index0==-2)&&(data_index!=-2)){		//24���ַ�һ��
	 LCD_ShowChar(100+16*hchar,100+50*lchar,data[data_index],24,0);
		hchar++;
		if(hchar>=24){
		hchar=0;
		lchar++;
		}
	}
	 data_index0=data_index;
		}




void mode3()		//ѧϰģʽ
{
	u16 countnum=0;
	while(KEY_Scan(0)==3);
	while(countnum<KEYN){
	while(KEY_Scan(0)!=3);
	delay_ms(10);	
	KeyBoard_Measure();
	P[0][countnum]=at;
	P[1][countnum]=bt;
	LCD_ShowxNum(10,(10+20*countnum),at,3,16,0);//1
	LCD_ShowxNum(60,(10+20*countnum),bt,3,16,0);//1
	countnum++;
	}
	
		while(KEY_Scan(0)!=1);
		
					FLAG_MENU=0;
					FLAG_MODE=3;
					LCD_Clear(WHITE);
					POINT_COLOR=BLACK;
					LCD_ShowString(5,120,60,60,16,"mouse");		//ģʽ1
					LCD_ShowString(5,150,60,60,16,"keyboard");		//ģʽ2��������
					LCD_ShowString(5,180,60,60,16,"training");	//ģʽ3��ѵ��ģʽ
					LCD_ShowString(5,210,60,60,16,"  ");	//ģʽ4 
					LCD_ShowString(5,240,60,60,16,"maze");	//ģʽ5
					LCD_ShowString(5,270,60,60,16,"mouse");	//ģʽ6
					LCD_ShowString(5,300,60,60,16,"test");	//ģʽ7 �۲�����ͷͼ��
					LCD_ShowString(80,180,60,60,16,"<--");
}


void mode4()	
{
}

void mode5()	//�Թ�
{  
	int i=0,j=0,xx,yy;
	 POINT_COLOR=BLACK;
	 for (i=0;i<10;i++)
	 for(j=0;j<10;j++)
	 {if (laby[i][j]==1) 
		 for(xx=1;xx<11;xx++)
		 for(yy=1;yy<11;yy++)
		   {
	       LCD_DrawPoint(50+i*10+yy,100+j*10+xx);
			 }
		}
   i=1;
	 j=3;
	 int i0,j0;
	 POINT_COLOR=RED;
	 for(xx=4;xx<8;xx++)
	 for(yy=4;yy<8;yy++)
		   {
	       LCD_DrawPoint(50+i*10+yy,100+j*10+xx);
			 }
	 while(KEY_Scan(0)!=1)
	 {
	 KeyBoard_Measure();
	 KeyBoard_Switch(at,bt);
	 if((data_index0==-2)&&(data_index!=-2))
	{
	   if (data[data_index]=='A')
		 if(laby[i][j+1]==0)
		 {
			 i0=i;j0=j;
			 j=j+1;
		 }
		 else if (data[data_index]=='W')
		 if(laby[i-1][j]==0)
		 {
			 i0=i;j0=j;
			 i-=1;
		 }
		 else if (data[data_index]=='D')
		 if(laby[i][j+1]==0)
		 {
			 i0=i;j0=j;
			 j=j-1;
		 }
		 else if (data[data_index]=='S')
		 if(laby[i][j+1]==0)
		 {
			 i0=i;j0=j;
			 i++;
		 }
		 if(!((i==i0)&&(j==j0))){
		 	 POINT_COLOR=RED;
			 for(xx=4;xx<8;xx++)
	     for(yy=4;yy<8;yy++)
		   {
	       LCD_DrawPoint(50+i*10+xx,100+j*10+yy);
			 }
			 POINT_COLOR=WHITE;
			 for(xx=2;xx<5;xx++)
	     for(yy=2;yy<5;yy++)
		   {
	       LCD_DrawPoint(50+i0*10+xx,100+j0*10+yy);
			 }
		  }
			 
	 }
	  data_index0=data_index;
   }
}

void mode6(){
	}

	void mode7(){		//������ʾ������test��
		//KeyBoard_Measure();
		camera_refresh();//������ʾ
	}

//#endif