#include "sys.h"
#include "my_FDC2214.h"
#include "myiic.h"
#include "delay.h"
#include "lcd.h"

u16 FDC2214_Read2Byte(u8 num,u8 reg_addr){//���ؽ��
	u16 reg_data=0;
	u16 temp=0;
  if(num==1){
	IIC_Start(1);
	IIC_Send_Byte(1,WRITE_ADDR); 
	if(IIC_Wait_Ack(1))return 0;
	IIC_Send_Byte(1,reg_addr);   
	if(IIC_Wait_Ack(1))return 0;
	IIC_Start(1);
	IIC_Send_Byte(1,READ_ADDR);
	if(IIC_Wait_Ack(1))return 0;
	reg_data= IIC_Read_Byte(1,1);
	reg_data=(reg_data<<8)&0xFF00;
	temp=IIC_Read_Byte(1,0);
	IIC_Stop(1);
	reg_data|=temp;
	return reg_data;		
	}else{
	IIC_Start(2);
	IIC_Send_Byte(2,WRITE_ADDR); 
	if(IIC_Wait_Ack(2))return 0;
	IIC_Send_Byte(2,reg_addr);   
	if(IIC_Wait_Ack(2))return 0;
	IIC_Start(2);
	IIC_Send_Byte(2,READ_ADDR);
	if(IIC_Wait_Ack(2))return 0;
	reg_data= IIC_Read_Byte(2,1);
	reg_data=(reg_data<<8)&0xFF00;
	temp=IIC_Read_Byte(2,0);
	IIC_Stop(2);
	reg_data|=temp;
	return reg_data;		
	}	

}

u8 FDC2214_Write2Byte(u8 num,u8 reg_addr,u16 reg_data){//�ɹ�1ʧ��0
	u8 data_high=(u8)((reg_data&0xFF00)>>8);
	u8 data_low=(u8)reg_data&0x00FF;
	if(num==1){
	IIC_Start(1);
	IIC_Send_Byte(1,WRITE_ADDR);   
	if(IIC_Wait_Ack(1))return 0;
	IIC_Send_Byte(1,reg_addr );     
	if(IIC_Wait_Ack(1))return 0;	
	IIC_Send_Byte(1,data_high);
	if(IIC_Wait_Ack(1))return 0;	
  IIC_Send_Byte(1,data_low);
	if(IIC_Wait_Ack(1))return 0;	 	
	IIC_Stop(1); 
	delay_ms(5);//������5ms�ӳ�
	return 1;		
	}else{
	IIC_Start(2);
	IIC_Send_Byte(2,WRITE_ADDR);   
	if(IIC_Wait_Ack(2))return 0;
	IIC_Send_Byte(2,reg_addr );     
	if(IIC_Wait_Ack(2))return 0;	
	IIC_Send_Byte(2,data_high);
	if(IIC_Wait_Ack(2))return 0;	
  IIC_Send_Byte(2,data_low);
	if(IIC_Wait_Ack(2))return 0;	 	
	IIC_Stop(2); 
	delay_ms(5);//������5ms�ӳ�
	return 1;		
	}

}

u32 FDC2214_ReadData(u8 num,u8 ch,u8 MSBORLSB){
   	u32 data_temp=0;
	
	switch(MSBORLSB){
		case MSB:data_temp=FDC2214_Read2Byte(num,0x02*ch);break;
		case LSB:data_temp=FDC2214_Read2Byte(num,0x02*ch+1);break;
		case BOTH:data_temp=(FDC2214_Read2Byte(num,0x02*ch)<<16)+FDC2214_Read2Byte(num,0x02*ch+1);break;
		default: return 0;
	}
	
//	IIC_Start();
//	IIC_Send_Byte(WRITE_ADDR); 
//	if(IIC_Wait_Ack())return 0;
//	IIC_Send_Byte(0x02*ch);   
//	if(IIC_Wait_Ack())return 0;
//	IIC_Start();
//	IIC_Send_Byte(READ_ADDR);
//	if(IIC_Wait_Ack())return 0;
//	data_temp= IIC_Read_Byte(1);
//	data_temp=data_temp<<8;
//	data_temp|=IIC_Read_Byte(1);
//	data_temp=data_temp<<8;
//	data_temp|=IIC_Read_Byte(1);
//	data_temp=data_temp<<8;
//	data_temp|=IIC_Read_Byte(0);
//	IIC_Stop();
	
	return data_temp;
}

void FDC2214_Init(void){
	u8 a=0;
	a=FDC2214_Write2Byte(1,RCOUNT0,0xFFFF);
	a+=FDC2214_Write2Byte(1,RCOUNT1,0x8329);
	a+=FDC2214_Write2Byte(1,RCOUNT2,0x8329);
	a+=FDC2214_Write2Byte(1,RCOUNT3,0x8329);
	
	a+=FDC2214_Write2Byte(1,SETTLECOUNT0,0x0FFF);//0a60
	a+=FDC2214_Write2Byte(1,SETTLECOUNT1,0x000A);
	a+=FDC2214_Write2Byte(1,SETTLECOUNT2,0x000A);
	a+=FDC2214_Write2Byte(1,SETTLECOUNT3,0x000A);
	
	a+=FDC2214_Write2Byte(1,CLK_DIVIDERS0,0x2002);//500a
	a+=FDC2214_Write2Byte(1,CLK_DIVIDERS1,0x2002);
	a+=FDC2214_Write2Byte(1,CLK_DIVIDERS2,0x2002);
	a+=FDC2214_Write2Byte(1,CLK_DIVIDERS3,0x2002);
	
	//a+=FDC2214_Write2Byte(RESET_DEV,0x0200);
	
	//FDC2214_Write2Byte(0x19,0x0000);
	
	a+=FDC2214_Write2Byte(1,MUX_CONFIG,0xC20D);//??//0801
	
	a+=FDC2214_Write2Byte(1,DRIVE_CURRENT0,0xF800);//9800
	a+=FDC2214_Write2Byte(1,DRIVE_CURRENT1,0xF800);
	a+=FDC2214_Write2Byte(1,DRIVE_CURRENT2,0xF800);
	a+=FDC2214_Write2Byte(1,DRIVE_CURRENT3,0xF800);
	
	a+=FDC2214_Write2Byte(1,CONFIG,0x1401);//2451//1501
	//LCD_ShowNum(10,110,a,5,16); 
	a=0;
	a=FDC2214_Write2Byte(2,RCOUNT0,0xFFFF);
	a+=FDC2214_Write2Byte(2,RCOUNT1,0x8329);
	a+=FDC2214_Write2Byte(2,RCOUNT2,0x8329);
	a+=FDC2214_Write2Byte(2,RCOUNT3,0x8329);
	
	a+=FDC2214_Write2Byte(2,SETTLECOUNT0,0x0FFF);//0a60
	a+=FDC2214_Write2Byte(2,SETTLECOUNT1,0x000A);
	a+=FDC2214_Write2Byte(2,SETTLECOUNT2,0x000A);
	a+=FDC2214_Write2Byte(2,SETTLECOUNT3,0x000A);
	
	a+=FDC2214_Write2Byte(2,CLK_DIVIDERS0,0x2002);//500a
	a+=FDC2214_Write2Byte(2,CLK_DIVIDERS1,0x2002);
	a+=FDC2214_Write2Byte(2,CLK_DIVIDERS2,0x2002);
	a+=FDC2214_Write2Byte(2,CLK_DIVIDERS3,0x2002);
	
	//a+=FDC2214_Write2Byte(RESET_DEV,0x0200);
	
	//FDC2214_Write2Byte(0x19,0x0000);
	
	a+=FDC2214_Write2Byte(2,MUX_CONFIG,0xC20D);//??//0801
	
	a+=FDC2214_Write2Byte(2,DRIVE_CURRENT0,0xF800);//9800
	a+=FDC2214_Write2Byte(2,DRIVE_CURRENT1,0xF800);
	a+=FDC2214_Write2Byte(2,DRIVE_CURRENT2,0xF800);
	a+=FDC2214_Write2Byte(2,DRIVE_CURRENT3,0xF800);
	
	a+=FDC2214_Write2Byte(2,CONFIG,0x1401);//2451//1501
	//LCD_ShowNum(10,129,a,5,16);	
}
