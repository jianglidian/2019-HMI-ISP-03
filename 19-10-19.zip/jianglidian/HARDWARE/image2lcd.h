#ifndef __IMAGE2LCD_H
#define __IMAGE2LCD_H
#include "sys.h"
//ͼ������ͷ�ṹ��  
__packed typedef struct _HEADCOLOR
{
   unsigned char scan;
   unsigned char gray;
   unsigned short w;
   unsigned short h;
   unsigned char is565;
   unsigned char rgb;
}HEADCOLOR; 

void Image2LCD(u16 x,u16 y,u8 * imgx);

#endif
