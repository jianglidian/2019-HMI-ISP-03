#include "sys.h"

#define READ_ADDR  		0x55
#define WRITE_ADDR 		0x54

#define DATA0_MSB     0x00
#define DATA0_LSB     0x01
#define DATA1_MSB     0x02
#define DATA1_LSB     0x03
#define DATA2_MSB  		0x04
#define DATA2_LSB     0x05
#define DATA3_MSB 		0x06
#define DATA3_LSB     0x07
#define RCOUNT0    		0x08
#define RCOUNT1    		0x09
#define RCOUNT2    		0x0A
#define RCOUNT3    		0x0B
#define SETTLECOUNT0  0x10
#define SETTLECOUNT1  0x11
#define SETTLECOUNT2  0x12
#define SETTLECOUNT3  0x13
#define CLK_DIVIDERS0 0x14
#define CLK_DIVIDERS1 0x15
#define CLK_DIVIDERS2 0x16
#define CLK_DIVIDERS3 0x17

#define STATUS_CONFIG 0x19
#define MUX_CONFIG    0x1B
#define RESET_DEV     0x1C

#define DRIVE_CURRENT0 0x1E
#define DRIVE_CURRENT1 0x1F
#define DRIVE_CURRENT2 0x20
#define DRIVE_CURRENT3 0x21

#define CONFIG        0x1A

#define MSB           0x00
#define LSB           0x01
#define BOTH          0x02


void FDC2214_Init(void);//�ɹ�1ʧ��0
u16 FDC2214_Read2Byte(u8 num,u8 reg_addr);//���ؽ��
u8 FDC2214_Write2Byte(u8 num,u8 reg_addr,u16 reg_data);//�ɹ�1ʧ��0
u32 FDC2214_ReadData(u8 num,u8 ch,u8 MSBORLSB);
float Cap_Calculate(u8 index);
float Cap2_Calculate(u8 index);
