#include "sys.h"
#include "delay.h"  
#include "usart.h"  
#include "lcd.h"
#include "ov7670.h"
#include "timer.h"	  		 
#include "sccb.h"	
#include "exti.h"
#include "stm32f4xx.h"
#include "key.h"
#include "math.h"
#include "image2lcd.h"
#define THRESHOLD 25   //�궨����ֵ



//ALIENTEK ̽����STM32F407������ ʵ��13
//TFTLCD��ʾʵ��  
//����֧�֣�www.openedv.com
//�������������ӿƼ����޹�˾
extern u8 ov_sta;	//��exit.c���涨��
extern u8 ov_frame;	//��timer.c���涨��	
u16 color,color_min=1000;
u16 hchar=0,lchar=0;

 void camera_refresh(void)	//������ʾ
{
	u32 j; 
	if(ov_sta==2)
	{   
		LCD_Scan_Dir(U2D_L2R);		//���ϵ���,������ 
	  LCD_Set_Window((lcddev.width-320)/2,(lcddev.height-240)/2,320,240);
		LCD_WriteRAM_Prepare();     //��ʼд��GRAM	
		OV7670_RRST=0;				//��ʼ��λ��ָ�� 
		OV7670_RCK=0;
		OV7670_RCK=1;
		OV7670_RCK=0;
		OV7670_RRST=1;				//��λ��ָ����� 
		OV7670_RCK=1;  
		for(j=0;j<76800;j++)	//�ֱ���240*320=76800
		{
			OV7670_RCK=0;
			color=GPIOF->IDR&0XFF;	//������
			OV7670_RCK=1; 
			color<<=8;  
			OV7670_RCK=0;
			color|=GPIOF->IDR&0XFF;	//������
			if (color>=THRESHOLD) color=255;
			else color=1;  //��ֵ��
			OV7670_RCK=1; 
			LCD->LCD_RAM=color;  
		}   							 
		EXTI->PR=1<<9;     			//���LINE9�ϵ��жϱ�־λ
		ov_sta=0;					//��ʼ��һ�βɼ�
		LCD_Scan_Dir(DFT_SCAN_DIR);	//�ָ�Ĭ��ɨ�跽�� 
	} 
}	


void mode1();
void mode2();
void mode3();
void mode4();
void mode5();
void mode6();
void mode7();
int laby[10][10]={
    {1,1,1,1,1,1,1,1,1,1},
    {1,0,0,0,0,0,0,1,1,1},
    {1,0,1,1,1,1,1,0,0,1},
    {1,0,1,0,0,0,0,0,0,1},
    {1,0,0,0,1,0,1,1,1,1},
    {1,1,1,1,0,0,1,1,1,1},
    {1,0,0,0,0,1,1,1,1,1},
    {1,0,1,1,0,0,1,1,1,1},
    {1,0,0,0,0,0,0,0,0,1},
    {1,1,1,1,1,1,1,1,1,1}
};
double ca,h;
static u8 FLAG_MENU=0;
static u8 FLAG_MODE=1;

int main(void)
{
	u8 key;           //�����ֵ
	u8 key2;
	KEY_Init();  
	uart_init(115200);
	delay_init(84);
	LCD_Init();
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);//����ϵͳ�ж����ȼ�����2
	LCD_Set_Window(0,0,1000,1000);
	delay_ms(100);
	TIM4_Ctrl_Init(20000-1,84-1);  //20ms

	Stm32_Clock_Init(336,8,2,7);//����ʱ��,168Mhz 
	delay_init(168);			//��ʱ��ʼ��  
	uart_init(115200);		//��ʼ�����ڲ�����Ϊ115200 
 	LCD_Init();
  OV7670_Init(); 
	while(OV7670_Init())//��ʼ��OV7670
	{
		LCD_ShowString(60,230,200,16,16,"OV7670 Error!!");
		delay_ms(200);
	    LCD_Fill(60,230,239,246,WHITE);
		delay_ms(200);
	}
 	LCD_ShowString(60,230,200,16,16,"OV7670 Init OK");
	delay_ms(1500);	 
	OV7670_Light_Mode(2);
	OV7670_Color_Saturation(2);
	OV7670_Brightness(4);
	OV7670_Contrast(2);	
	EXTI9_Init();						//ʹ�ܶ�ʱ������ 
  OV7670_Window_Set(10,174,240,320);	//���ô���	
  OV7670_CS=0;
	
	POINT_COLOR=BLACK;
	LCD_ShowString(5,120,60,60,16,"  ");		//ģʽ1
	LCD_ShowString(5,150,60,60,16,"keyboard");		//ģʽ2��������
	LCD_ShowString(5,180,60,60,16,"training");	//ģʽ3��ѧϰģʽ
	LCD_ShowString(5,210,60,60,16,"fdc");	//ģʽ4 
	LCD_ShowString(5,240,60,60,16,"maze");	//ģʽ5 ���Թ�
	LCD_ShowString(5,270,60,60,16,"mouse");	//ģʽ6�����
	LCD_ShowString(5,300,60,60,16,"test");	//ģʽ7 �۲�����ͷͼ��
	LCD_ShowString(80,120,60,60,16,"<--");
	
		while(1){
		key=KEY_Scan(0);		//�õ���ֵ
	  if(FLAG_MENU==0)//�ڲ˵�������
		{	
		if(key)
		{				   
			switch(key)
			{				 
				case KEYUP_PRES:	//����
				{
					if(FLAG_MODE==7)
					{
					LCD_Clear(WHITE);
					POINT_COLOR=BLACK;
					LCD_ShowString(5,120,60,60,16,"  ");		//ģʽ1
					LCD_ShowString(5,150,60,60,16,"keyboard");		//ģʽ2��������
					LCD_ShowString(5,180,60,60,16,"training");	//ģʽ3��ѵ��ģʽ
					LCD_ShowString(5,210,60,60,16,"fdc");	//ģʽ4 
					LCD_ShowString(5,240,60,60,16,"maze");	//ģʽ5
					LCD_ShowString(5,270,60,60,16,"mouse");	//ģʽ6�����
					LCD_ShowString(5,300,60,60,16,"test");	//ģʽ7 �۲�����ͷͼ��
					LCD_ShowString(80,270,60,60,16,"<--");
					FLAG_MODE=6;
					}
					else if(FLAG_MODE==6)
					{
					LCD_Clear(WHITE);
					POINT_COLOR=BLACK;
					LCD_ShowString(5,120,60,60,16,"  ");		//ģʽ1
					LCD_ShowString(5,150,60,60,16,"keyboard");		//ģʽ2��������
					LCD_ShowString(5,180,60,60,16,"training");	//ģʽ3��ѵ��ģʽ
					LCD_ShowString(5,210,60,60,16,"fdc");	//ģʽ4 
					LCD_ShowString(5,240,60,60,16,"maze");	//ģʽ5
					LCD_ShowString(5,270,60,60,16,"mouse");	//ģʽ6�����
					LCD_ShowString(5,300,60,60,16,"test");	//ģʽ7 �۲�����ͷͼ��
					LCD_ShowString(80,240,60,60,16,"<--");
					FLAG_MODE=5;
					}
					else if(FLAG_MODE==5)
					{
					LCD_Clear(WHITE);
					POINT_COLOR=BLACK;
					LCD_ShowString(5,120,60,60,16,"  ");		//ģʽ1
					LCD_ShowString(5,150,60,60,16,"keyboard");		//ģʽ2��������
					LCD_ShowString(5,180,60,60,16,"training");	//ģʽ3��ѵ��ģʽ
					LCD_ShowString(5,210,60,60,16,"fdc");	//ģʽ4 
					LCD_ShowString(5,240,60,60,16,"maze");	//ģʽ5
					LCD_ShowString(5,270,60,60,16,"mouse");	//ģʽ6�����
					LCD_ShowString(5,300,60,60,16,"test");	//ģʽ7 �۲�����ͷͼ��
					LCD_ShowString(80,210,60,60,16,"<--");
					FLAG_MODE=4;
					}
					else if(FLAG_MODE==4)
					{
					LCD_Clear(WHITE);
					POINT_COLOR=BLACK;
					LCD_ShowString(5,120,60,60,16,"  ");		//ģʽ1
					LCD_ShowString(5,150,60,60,16,"keyboard");		//ģʽ2��������
					LCD_ShowString(5,180,60,60,16,"training");	//ģʽ3��ѵ��ģʽ
					LCD_ShowString(5,210,60,60,16,"fdc");	//ģʽ4 
					LCD_ShowString(5,240,60,60,16,"maze");	//ģʽ5
					LCD_ShowString(5,270,60,60,16,"mouse");	//ģʽ6�����
					LCD_ShowString(5,300,60,60,16,"test");	//ģʽ7 �۲�����ͷͼ��
					LCD_ShowString(80,180,60,60,16,"<--");
					FLAG_MODE=3;
					}
					else if(FLAG_MODE==3)
					{
					LCD_Clear(WHITE);
					POINT_COLOR=BLACK;
					LCD_ShowString(5,120,60,60,16,"  ");		//ģʽ1
					LCD_ShowString(5,150,60,60,16,"keyboard");		//ģʽ2��������
					LCD_ShowString(5,180,60,60,16,"training");	//ģʽ3��ѵ��ģʽ
					LCD_ShowString(5,210,60,60,16,"fdc");	//ģʽ4 
					LCD_ShowString(5,240,60,60,16,"maze");	//ģʽ5
					LCD_ShowString(5,270,60,60,16,"mouse");	//ģʽ6�����
					LCD_ShowString(5,300,60,60,16,"test");	//ģʽ7 �۲�����ͷͼ��
					LCD_ShowString(80,150,60,60,16,"<--");
					FLAG_MODE=2;
					}
					else if(FLAG_MODE==2)
					{
					LCD_Clear(WHITE);
					POINT_COLOR=BLACK;
					LCD_ShowString(5,120,60,60,16,"  ");		//ģʽ1
					LCD_ShowString(5,150,60,60,16,"keyboard");		//ģʽ2��������
					LCD_ShowString(5,180,60,60,16,"training");	//ģʽ3��ѵ��ģʽ
					LCD_ShowString(5,210,60,60,16,"fdc");	//ģʽ4 
					LCD_ShowString(5,240,60,60,16,"maze");	//ģʽ5
					LCD_ShowString(5,270,60,60,16,"mouse");	//ģʽ6�����
					LCD_ShowString(5,300,60,60,16,"test");	//ģʽ7 �۲�����ͷͼ��
					LCD_ShowString(80,120,60,60,16,"<--");
					FLAG_MODE=1;
					}
					break;
				}
				case KEYRIGHT_PRES:	//����
					break;
				case KEYDOWN_PRES:	//����
				{
					if(FLAG_MODE==1)
					{
					POINT_COLOR=BLACK;
					LCD_Clear(WHITE);
					POINT_COLOR=BLACK;
					LCD_ShowString(5,120,60,60,16,"  ");		//ģʽ1
					LCD_ShowString(5,150,60,60,16,"keyboard");		//ģʽ2��������
					LCD_ShowString(5,180,60,60,16,"training");	//ģʽ3��ѵ��ģʽ
					LCD_ShowString(5,210,60,60,16,"fdc");	//ģʽ4 
					LCD_ShowString(5,240,60,60,16,"maze");	//ģʽ5
					LCD_ShowString(5,270,60,60,16,"mouse");	//ģʽ6�����
					LCD_ShowString(5,300,60,60,16,"test");	//ģʽ7 �۲�����ͷͼ��
					LCD_ShowString(80,150,60,60,16,"<--");
					FLAG_MODE=2;
					}
					else if(FLAG_MODE==2)
					{
					POINT_COLOR=BLACK;
					LCD_Clear(WHITE);
					POINT_COLOR=BLACK;
					LCD_ShowString(5,120,60,60,16,"  ");		//ģʽ1
					LCD_ShowString(5,150,60,60,16,"keyboard");		//ģʽ2��������
					LCD_ShowString(5,180,60,60,16,"training");	//ģʽ3��ѵ��ģʽ
					LCD_ShowString(5,210,60,60,16,"fdc");	//ģʽ4 
					LCD_ShowString(5,240,60,60,16,"maze");	//ģʽ5
					LCD_ShowString(5,270,60,60,16,"mouse");	//ģʽ6�����
					LCD_ShowString(5,300,60,60,16,"test");	//ģʽ7 �۲�����ͷͼ��
					LCD_ShowString(80,180,60,60,16,"<--");
						FLAG_MODE=3;
					}
					else if(FLAG_MODE==3)
					{
					POINT_COLOR=BLACK;
					LCD_Clear(WHITE);
					POINT_COLOR=BLACK;
					LCD_ShowString(5,120,60,60,16,"  ");		//ģʽ1
					LCD_ShowString(5,150,60,60,16,"keyboard");		//ģʽ2��������
					LCD_ShowString(5,180,60,60,16,"training");	//ģʽ3��ѵ��ģʽ
					LCD_ShowString(5,210,60,60,16,"fdc");	//ģʽ4 
					LCD_ShowString(5,240,60,60,16,"maze");	//ģʽ5
					LCD_ShowString(5,270,60,60,16,"mouse");	//ģʽ6�����
					LCD_ShowString(5,300,60,60,16,"test");	//ģʽ7 �۲�����ͷͼ��
					LCD_ShowString(80,210,60,60,16,"<--");
						FLAG_MODE=4;						
					}
					else if(FLAG_MODE==4)
					{
					POINT_COLOR=BLACK;
					LCD_Clear(WHITE);
					POINT_COLOR=BLACK;
					LCD_ShowString(5,120,60,60,16,"  ");		//ģʽ1
					LCD_ShowString(5,150,60,60,16,"keyboard");		//ģʽ2��������
					LCD_ShowString(5,180,60,60,16,"training");	//ģʽ3��ѵ��ģʽ
					LCD_ShowString(5,210,60,60,16,"fdc");	//ģʽ4
					LCD_ShowString(5,240,60,60,16,"maze");	//ģʽ5
					LCD_ShowString(5,270,60,60,16,"mouse");	//ģʽ6�����
					LCD_ShowString(5,300,60,60,16,"test");	//ģʽ7 �۲�����ͷͼ��
					LCD_ShowString(80,240,60,60,16,"<--");
						FLAG_MODE=5;						
					}
					else if(FLAG_MODE==5)
					{
					POINT_COLOR=BLACK;
					LCD_Clear(WHITE);
					POINT_COLOR=BLACK;
					LCD_ShowString(5,120,60,60,16,"  ");		//ģʽ1
					LCD_ShowString(5,150,60,60,16,"keyboard");		//ģʽ2��������
					LCD_ShowString(5,180,60,60,16,"training");	//ģʽ3��ѵ��ģʽ
					LCD_ShowString(5,210,60,60,16,"fdc");	//ģʽ4 
					LCD_ShowString(5,240,60,60,16,"maze");	//ģʽ5
					LCD_ShowString(5,270,60,60,16,"mouse");	//ģʽ6�����
					LCD_ShowString(5,300,60,60,16,"test");	//ģʽ7 �۲�����ͷͼ��
					LCD_ShowString(80,270,60,60,16,"<--");
						FLAG_MODE=6;						
					}
					else if(FLAG_MODE==6)
					{
					POINT_COLOR=BLACK;
					LCD_Clear(WHITE);
					POINT_COLOR=BLACK;
					LCD_ShowString(5,120,60,60,16,"  ");		//ģʽ1
					LCD_ShowString(5,150,60,60,16,"keyboard");		//ģʽ2��������
					LCD_ShowString(5,180,60,60,16,"training");	//ģʽ3��ѵ��ģʽ
					LCD_ShowString(5,210,60,60,16,"fdc");	//ģʽ4 
					LCD_ShowString(5,240,60,60,16,"maze");	//ģʽ5
					LCD_ShowString(5,270,60,60,16,"mouse");	//ģʽ6�����
					LCD_ShowString(5,300,60,60,16,"test");	//ģʽ7 �۲�����ͷͼ��
					LCD_ShowString(80,300,60,60,16,"<--");
						FLAG_MODE=7;						
					}
					break;
				}
				case KEYLEFT_PRES:	//ȷ�� 
				{
					if(FLAG_MODE==1)
					{
						FLAG_MENU=MODE_1;
						LCD_Clear(WHITE);
					}
					if(FLAG_MODE==2)
					{
						FLAG_MENU=MODE_2;
						LCD_Clear(WHITE);
					}
					if(FLAG_MODE==3)
					{
						FLAG_MENU=MODE_3;
						LCD_Clear(WHITE);
					}
					if(FLAG_MODE==4)
					{
						FLAG_MENU=MODE_4;
						LCD_Clear(WHITE);
					}
					if(FLAG_MODE==5)
					{
						FLAG_MENU=MODE_5;
						LCD_Clear(WHITE);
					}
					if(FLAG_MODE==6)
					{
						FLAG_MENU=MODE_6;
						LCD_Clear(WHITE);
					}
					if(FLAG_MODE==7)
					{
						FLAG_MENU=MODE_7;
						LCD_Clear(WHITE);
					}
					break;
					}
			}
		}	
	}
			if(FLAG_MENU==MODE_1)//ģʽ1
			{
					LCD_ShowString(5,100,60,60,16,"1");
					while(KEY_Scan(0)!=1){mode1();}//�����˳���ʼ����mode1�����		
				FLAG_MENU=0;
				FLAG_MODE=1;
					LCD_Clear(WHITE);
						POINT_COLOR=BLACK;
					LCD_ShowString(5,120,60,60,16,"  ");		//ģʽ1
					LCD_ShowString(5,150,60,60,16,"keyboard");		//ģʽ2��������
					LCD_ShowString(5,180,60,60,16,"training");	//ģʽ3��ѵ��ģʽ
					LCD_ShowString(5,210,60,60,16,"fdc");	//ģʽ4 
					LCD_ShowString(5,240,60,60,16,"maze");	//ģʽ5
					LCD_ShowString(5,270,60,60,16,"mouse");	//ģʽ6
					LCD_ShowString(5,300,60,60,16,"test");	//ģʽ7 �۲�����ͷͼ��
					LCD_ShowString(80,120,60,60,16,"<--");
			}	
			
			if(FLAG_MENU==MODE_2)//ģʽ2��ȭ
		{
			TIM_Cmd(TIM4, DISABLE);  //ʹ��TIM4	
			hchar=0;
			lchar=0;
					LCD_ShowString(5,100,60,60,16,"keyboard");
					while(KEY_Scan(0)!=1){mode2();}
				FLAG_MENU=0;
				FLAG_MODE=2;
					LCD_Clear(WHITE);
						POINT_COLOR=BLACK;
						LCD_ShowString(5,120,60,60,16,"  ");		//ģʽ1
					LCD_ShowString(5,150,60,60,16,"keyboard");		//ģʽ2��������
					LCD_ShowString(5,180,60,60,16,"training");	//ģʽ3��ѵ��ģʽ
					LCD_ShowString(5,210,60,60,16,"fdc");	//ģʽ4 
					LCD_ShowString(5,240,60,60,16,"maze");	//ģʽ5
					LCD_ShowString(5,270,60,60,16,"mouse");	//ģʽ6
					LCD_ShowString(5,300,60,60,16,"test");	//ģʽ7 �۲�����ͷͼ��
					LCD_ShowString(80,150,60,60,16,"<--");
		}
		
			if(FLAG_MENU==MODE_3)//ģʽ3ѵ��
		{
			TIM_Cmd(TIM4, DISABLE);  //ʹ��TIM4	
					LCD_ShowString(5,100,60,60,16,"training");
					mode3();
			}	
		

			if(FLAG_MENU==MODE_4)//ģʽ4
		{
			TIM_Cmd(TIM4, ENABLE);  //ʹ��TIM4	
					LCD_ShowString(5,100,60,60,16,"fdc");
					while(KEY_Scan(0)!=1){mode4();}//�����˳���ʼ����mode4�����	
					FLAG_MENU=0;
					FLAG_MODE=4;
					LCD_Clear(WHITE);
						POINT_COLOR=BLACK;
						LCD_ShowString(5,120,60,60,16,"  ");		//ģʽ1
					LCD_ShowString(5,150,60,60,16,"keyboard");		//ģʽ2��������
					LCD_ShowString(5,180,60,60,16,"training");	//ģʽ3��ѵ��ģʽ
					LCD_ShowString(5,210,60,60,16,"fdc");	//ģʽ4 
					LCD_ShowString(5,240,60,60,16,"  ");	//ģʽ5
					LCD_ShowString(5,270,60,60,16,"mouse");	//ģʽ6
					LCD_ShowString(5,300,60,60,16,"test");	//ģʽ7 �۲�����ͷͼ��
					LCD_ShowString(80,210,60,60,16,"<--");
			}	
		if(FLAG_MENU==MODE_5)//ģʽ5
		{
					LCD_ShowString(5,100,60,60,16,"maze");
					//mode5();
					while(KEY_Scan(0)!=1){mode5();}//�����˳���ʼ����mode4�����	
					FLAG_MENU=0;
					FLAG_MODE=5;
					LCD_Clear(WHITE);
						POINT_COLOR=BLACK;
						LCD_ShowString(5,120,60,60,16,"  ");		//ģʽ1
					LCD_ShowString(5,150,60,60,16,"keyboard");		//ģʽ2��������
					LCD_ShowString(5,180,60,60,16,"training");	//
					LCD_ShowString(5,210,60,60,16,"fdc");	//ģʽ4 
					LCD_ShowString(5,240,60,60,16,"maze");	//ģʽ5
					LCD_ShowString(5,270,60,60,16,"mouse");	//ģʽ6
					LCD_ShowString(5,300,60,60,16,"test");	//ģʽ7 �۲�����ͷͼ��
					LCD_ShowString(80,240,60,60,16,"<--");
			}	
		if(FLAG_MENU==MODE_6)//ģʽ6
		{
			TIM_Cmd(TIM4, ENABLE);  //ʹ��TIM4	
			key2=0;
			POINT_COLOR=RED;
					LCD_ShowString(5,100,60,60,16,"mouse");
		//			while(KEY_Scan(0)!=1){mode6();}//�����˳���ʼ����mode4�����	
		while(!(key2=KEY_Scan(0))){mode6();}
		if(key2==1)		{	FLAG_MENU=0;
					FLAG_MODE=6;
					LCD_Clear(WHITE);
						POINT_COLOR=BLACK;
						LCD_ShowString(5,120,60,60,16,"  ");		//ģʽ1
					LCD_ShowString(5,150,60,60,16,"keyboard");		//
					LCD_ShowString(5,180,60,60,16,"training");	//ģʽ3��ѵ��ģʽ
					LCD_ShowString(5,210,60,60,16,"fdc");	//ģʽ4 
					LCD_ShowString(5,240,60,60,16,"maze");	//ģʽ5
					LCD_ShowString(5,270,60,60,16,"mouse");	//
					LCD_ShowString(5,300,60,60,16,"test");	//ģʽ7 �۲�����ͷͼ��
					LCD_ShowString(80,270,60,60,16,"<--");
		   }
			}	
		if(FLAG_MENU==MODE_7)//ģʽ7
		{
			TIM_Cmd(TIM4, DISABLE);  //ʹ��TIM4	
					LCD_ShowString(5,100,60,60,16,"test");
					while(KEY_Scan(0)!=1){mode7();}//�����˳���ʼ����mode7�����	
					FLAG_MENU=0;
					FLAG_MODE=7;
					LCD_Clear(WHITE);
						POINT_COLOR=BLACK;
						LCD_ShowString(5,120,60,60,16,"  ");		//ģʽ1
					LCD_ShowString(5,150,60,60,16,"keyboard");		//ģʽ2��������
					LCD_ShowString(5,180,60,60,16,"training");	//ģʽ3��ѵ��ģʽ
					LCD_ShowString(5,210,60,60,16,"fdc");	//ģʽ4 
					LCD_ShowString(5,240,60,60,16,"maze");	//ģʽ5
					LCD_ShowString(5,270,60,60,16,"mouse");	//ģʽ6�����
					LCD_ShowString(5,300,60,60,16,"test");	//ģʽ7 �۲�����ͷͼ��
					LCD_ShowString(80,300,60,60,16,"<--");
			}	
	}	
}

void mode5()	//�Թ�
{  
	int i=0,j=0,xx,yy;
	 POINT_COLOR=BLACK;
	 for (i=0;i<10;i++)
	 for(j=0;j<10;j++)
	 {if (laby[i][j]==1) 
		 for(xx=1;xx<11;xx++)
		 for(yy=1;yy<11;yy++)
		   {
	       LCD_DrawPoint(50+i*10+yy,100+j*10+xx);
			 }
		}
   i=1;
	 j=3;
	 int i0,j0;
	 POINT_COLOR=RED;
	 for(xx=4;xx<8;xx++)
	 for(yy=4;yy<8;yy++)
		   {
	       LCD_DrawPoint(50+i*10+yy,100+j*10+xx);
			 }
}

	
	void mode7(){		//������ʾ������test��
		camera_refresh();//������ʾ
	 }
//#endif